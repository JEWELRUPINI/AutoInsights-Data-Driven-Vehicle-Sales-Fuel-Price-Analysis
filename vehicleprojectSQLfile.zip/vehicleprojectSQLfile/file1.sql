SELECT 'Traditional Vehicles' AS category, type, COUNT(*) AS count 
FROM traditional_vehicle_sales 
GROUP BY type
UNION ALL
SELECT 'EV Sales' AS category, type, COUNT(*) AS count
FROM ev_sales 
GROUP BY type
UNION ALL
SELECT 'Fuel Prices' AS category, type, COUNT(*) AS count
FROM fuel_prices 
GROUP BY type;




