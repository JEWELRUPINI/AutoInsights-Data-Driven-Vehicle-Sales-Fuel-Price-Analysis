SELECT Year, 
       SUM(Sales) AS total_sales, 
       'Traditional Vehicles' AS category  
FROM traditional_vehicle_sales  
GROUP BY Year
UNION ALL 
SELECT Year, 
       SUM(`EV Sales`) AS total_sales, 
       'EV Sales' AS category  
FROM ev_sales  
GROUP BY Year;

